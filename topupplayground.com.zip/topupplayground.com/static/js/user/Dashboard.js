import React, {
    useEffect,
    useState
} from "react";
import Layout from "../components/Layout/Layout";
import axios from "axios";
import {
    useSelector
} from "react-redux";
import "./Dashboard.css";
import {
    useLocation,
    useNavigate,
    useParams
} from "react-router-dom";
import DashboardLayout from "./components/DashboardLayout";
import InstallMobileIcon from "@mui/icons-material/InstallMobile";
import AccountBalanceWalletIcon from "@mui/icons-material/AccountBalanceWallet";

const Dashboard = () => {
    const {
        user
    } = useSelector((state) => state.user);
    const {
        balance
    } = useSelector((state) => state.data);
    const navigate = useNavigate();
    const [allOrders, setAllOrders] = useState(null);
    const [loading, setLoading] = useState(false);

    const getAllUserOrders = async () => {
        try {
            setLoading(true);
            const res = await axios.post(
                "/api/order/get-user-orders", {
                    email: user ? .email
                }, {
                    headers: {
                        Authorization: "Bearer " + localStorage.getItem("token"),
                    },
                }
            );
            if (res.data.success) {
                setAllOrders(res.data.data);
                setLoading(false);
            } else {
                setLoading(false);
            }
        } catch (error) {
            setLoading(false);
            console.log(error);
        }
    };

    useEffect(() => {
        if (user !== null) {
            getAllUserOrders();
        }
    }, [user]);

    return ( <
        Layout >
        <
        DashboardLayout >
        <
        div className = "dashboard-container" >
        <
        div className = "dash-card dash shadow mb-0 col-lg-6 col-12"
        onClick = {
            () => navigate("/orders")
        } >
        <
        div className = "count" >
        <
        h1 className = "m-0" >
        <
        b > {
            allOrders ? .length || 0
        } < /b> <
        /h1> <
        span className = "text-muted" > Orders < /span> <
        /div> <
        InstallMobileIcon className = "icon" / >
        <
        /div> <
        div className = "dash-card dash shadow mb-0 col-lg-6 col-12"
        onClick = {
            () => navigate("/wallet")
        } >
        <
        div className = "count" >
        <
        h1 className = "m-0" >
        <
        b > {
            parseFloat(balance).toFixed(2)
        } < /b> <
        /h1> <
        span className = "text-muted" > Wallet < /span> <
        /div> <
        AccountBalanceWalletIcon className = "icon" / >
        <
        /div> <
        /div> <
        /DashboardLayout> <
        /Layout>
    );
};

export default Dashboard;