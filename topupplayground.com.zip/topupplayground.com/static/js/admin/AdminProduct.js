import React, {
    useEffect,
    useState
} from "react";
import AdminLayout from "./components/AdminLayout";
import {
    message
} from "antd";
import SearchIcon from "@mui/icons-material/Search";
import EditIcon from "@mui/icons-material/Edit";
import DeleteIcon from "@mui/icons-material/Delete";
import axios from "axios";
import {
    useNavigate
} from "react-router-dom";
import {
    useDispatch,
    useSelector
} from "react-redux";
import getAllProducts from "../utils/productDataService";
import ReplayCircleFilledIcon from "@mui/icons-material/ReplayCircleFilled";
import "./AdminUsers.css";

const AdminProduct = () => {
    const navigate = useNavigate();
    const dispatch = useDispatch();
    const [searchQuery, setSearchQuery] = useState("");
    const [filteredUsers, setFilteredUsers] = useState(null);
    const [loading, setLoading] = useState(false);
    const [sequenceProducts, setSequenceProducts] = useState(null);
    const {
        products
    } = useSelector((state) => state.data);

    // delete product
    const handleDeleteProduct = async (id, images) => {
        const shouldDelete = window.confirm("Are you sure to delete?");
        if (shouldDelete) {
            try {
                const res = await axios.post(
                    "/api/product/delete-product", {
                        id,
                        images,
                    }, {
                        headers: {
                            Authorization: "Bearer " + localStorage.getItem("token"),
                        },
                    }
                );
                if (res.data.success) {
                    message.success(res.data.message);
                    getAllProducts(dispatch);
                } else {
                    message.error(res.data.message);
                }
            } catch (error) {
                console.error(error);
            }
        } else {
            // User clicked "Cancel" or closed the dialog
        }
    };
    // Search
    const handleSearch = () => {
        if (searchQuery.trim() === "") {
            setFilteredUsers(null);
        } else {
            const filtered = products.filter((product) => {
                return product ? .name.toLowerCase().includes(searchQuery.toLowerCase());
            });
            setFilteredUsers(filtered);
        }
    };

    useEffect(() => {
        handleSearch(); // Call handleSearch in useEffect
        // eslint-disable-next-line
    }, [searchQuery, products]);

    const filterProduct =
        filteredUsers && filteredUsers ? filteredUsers : products;

    async function handleStock(stock, id) {
        try {
            setLoading(true);
            const res = await axios.post(
                "/api/admin/handleStock", {
                    id: id,
                    stock: stock
                }, {
                    headers: {
                        Authorization: "Bearer " + localStorage.getItem("token"),
                    },
                }
            );
            if (res.data.success) {
                message.success(res.data.message);
                getAllProducts(dispatch);
                setLoading(false);
            } else {
                setLoading(false);
                message.error(res.data.message);
            }
        } catch (error) {
            console.log(error);
            setLoading(false);
        }
    }

    return ( <
        AdminLayout >
        <
        div className = "admin-users-container" >
        <
        div className = "page-title" >
        <
        h3 className = "m-0" > Products < /h3> <
        button onClick = {
            () => navigate("/admin-add-product")
        } >
        Add New <
        /button> <
        /div> <
        hr / >
        <
        div className = "table-container" >
        <
        div className = "tools" >
        <
        div className = "form-fields" >
        <
        SearchIcon className = "text-dark me-2" / >
        <
        input className = "mb-4"
        type = "search"
        name = "search"
        placeholder = "Search by name"
        value = {
            searchQuery
        }
        onChange = {
            (e) => setSearchQuery(e.target.value)
        }
        /> <
        /div> <
        /div> <
        table className = "table user-table" >
        <
        thead >
        <
        tr >
        <
        th > Image < /th> <
        th > Name < /th> <
        th > Category < /th> <
        th > API < /th> <
        th > Seq < /th> <
        th > Stock < /th> <
        th > Action < /th> <
        /tr> <
        /thead> <
        tbody > {
            filterProduct ? .map((product, index) => {
                return ( <
                    tr key = {
                        index
                    } >
                    <
                    td >
                    <
                    img src = {
                        `https://topupplayground.com/${product?.image}`
                    }
                    alt = ""
                    loading = "lazy" /
                    >
                    <
                    /td> <
                    td >
                    <
                    small > {
                        product ? .name
                    } < /small> <
                    /td> <
                    td >
                    <
                    small > {
                        product ? .productCategory
                    } < /small> <
                    /td> <
                    td >
                    <
                    small > {
                        product ? .apiName || "Non API"
                    } < /small> <
                    /td> <
                    td >
                    <
                    small > {
                        product ? .seq
                    } < /small> <
                    /td> <
                    td > {
                        loading && ( <
                            div class = "spinner-grow spinner-grow-sm"
                            role = "status" >
                            <
                            span class = "visually-hidden" > Loading... < /span> <
                            /div>
                        )
                    } <
                    select className = "form-select"
                    value = {
                        product ? .stock
                    }
                    name = "stock"
                    onChange = {
                        (e) =>
                        handleStock(e.target.value, product ? ._id)
                    } >
                    <
                    option value = "Yes" > Yes < /option> <
                    option value = "No" > No < /option> <
                    /select> { /* <small>{product?.stock}</small> */ } <
                    /td> <
                    td >
                    <
                    div className = "d-flex gap-2" >
                    <
                    EditIcon onClick = {
                        () =>
                        navigate(`/admin-edit-product/${product?._id}`)
                    }
                    /> <
                    DeleteIcon style = {
                        {
                            cursor: "pointer"
                        }
                    }
                    onClick = {
                        () =>
                        handleDeleteProduct(product ? ._id, product ? .image)
                    }
                    className = "text-danger" /
                    >
                    <
                    /div> <
                    /td> <
                    /tr>
                );
            })
        } <
        /tbody> <
        /table> <
        div className = "pagination" > < /div> <
        /div> <
        /div> <
        /AdminLayout>
    );
};

export default AdminProduct;