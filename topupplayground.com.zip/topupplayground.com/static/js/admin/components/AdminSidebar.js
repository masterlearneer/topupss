import React from "react";
import HomeIcon from "@mui/icons-material/Home";
import GroupIcon from "@mui/icons-material/Group";
import PaymentIcon from "@mui/icons-material/Payment";
import ReceiptIcon from "@mui/icons-material/Receipt";
import HelpIcon from "@mui/icons-material/Help";
import AddCardIcon from '@mui/icons-material/AddCard';
import InventoryIcon from "@mui/icons-material/Inventory";
import DiscountIcon from "@mui/icons-material/Discount";
import NotificationsActiveIcon from "@mui/icons-material/NotificationsActive";
import CurrencyExchangeIcon from "@mui/icons-material/CurrencyExchange";
import ViewCarouselIcon from "@mui/icons-material/ViewCarousel";
import PostAddIcon from '@mui/icons-material/PostAdd';
import CollectionsIcon from "@mui/icons-material/Collections";
import {
    Link
} from "react-router-dom";
import "./AdminSidebar.css";

const AdminSidebar = () => {
    return ( <
        div className = "admin-sidebar-container" >
        <
        span >
        <
        small > MAIN < /small> <
        /span> <
        ul >
        <
        li >
        <
        Link to = "/admin-dashboard" >
        <
        HomeIcon className = "me-2 icon" / >
        Dashboard <
        /Link> <
        /li> <
        /ul> <
        span >
        <
        small > LISTS < /small> <
        /span> <
        ul >
        <
        li >
        <
        Link to = "/admin-orders" >
        <
        ReceiptIcon className = "me-2 icon" / >
        Orders <
        /Link> <
        /li> <
        li >
        <
        Link to = "/admin-products" >
        <
        InventoryIcon className = "me-2 icon" / >
        Products <
        /Link> <
        /li> <
        li >
        <
        Link to = "/admin-users" >
        <
        GroupIcon className = "me-2 icon" / >
        Customers <
        /Link> <
        /li> <
        li >
        <
        Link to = "/admin-payments" >
        <
        PaymentIcon className = "me-2 icon" / >
        Payments <
        /Link> <
        /li> <
        li >
        <
        Link to = "/admin-wallet-history" >
        <
        PaymentIcon className = "me-2 icon" / >
        Wallet History <
        /Link> <
        /li> <
        li >
        <
        Link to = "/admin-queries" >
        <
        HelpIcon className = "me-2 icon" / >
        Queries <
        /Link> <
        /li> <
        li >
        <
        Link to = "/admin-add-money" >
        <
        AddCardIcon className = "me-2 icon" / >
        Add Money <
        /Link> <
        /li> <
        li >
        <
        Link to = "/admin-add-coupon" >
        <
        DiscountIcon className = "me-2 icon" / >
        Coupons <
        /Link> <
        /li> <
        li >
        <
        Link to = "/admin-banners" >
        <
        ViewCarouselIcon className = "me-2 icon" / >
        Banners <
        /Link> <
        /li> <
        li >
        <
        Link to = "/admin-notification" >
        <
        NotificationsActiveIcon className = "me-2 icon" / >
        Notification <
        /Link> <
        /li> <
        li >
        <
        Link to = "/admin-refer-earn" >
        <
        CurrencyExchangeIcon className = "me-2 icon" / >
        Refer & Earn <
        /Link> <
        /li> <
        li >
        <
        Link to = "/admin-gallery" >
        <
        CollectionsIcon className = "me-2 icon" / >
        Gallery <
        /Link> <
        /li> <
        li >
        <
        Link to = "/add-blog" >
        <
        PostAddIcon className = "me-2 icon" / >
        Add Blog <
        /Link> <
        /li> <
        li >
        <
        Link to = "/add-reward-list" >
        <
        PostAddIcon className = "me-2 icon" / >
        Add Reward List <
        /Link> <
        /li> <
        li >
        <
        Link to = "/add-product-packages-category" >
        <
        PostAddIcon className = "me-2 icon" / >
        Add Packages Category <
        /Link> <
        /li> <
        /ul> <
        /div>
    );
};

export default AdminSidebar;