import React, {
    useEffect
} from "react";
import AdminHeader from "./AdminHeader";
import AdminSidebar from "./AdminSidebar";
import {
    useSelector
} from "react-redux";
import {
    Navigate,
    useNavigate
} from "react-router-dom";

const AdminLayout = ({
    children
}) => {
    const {
        user
    } = useSelector((state) => state.user);
    const navigate = useNavigate();

    if (!user ? .isAdmin) {
        return <Navigate to = "/login" / > ;
    }

    return ( <
        div className = "admin-layout-container" >
        <
        AdminHeader / >
        <
        div className = "admin-body" >
        <
        div className = "admin-sidebar d-none d-md-none d-lg-block" >
        <
        AdminSidebar / >
        <
        /div> <
        div className = "admin-body-content p-2" > {
            children
        } < /div> <
        /div> <
        footer >
        <
        div className = "admin-footer" >
        <
        span > ADMIN < /span> <
        span > ~aashirdigital < /span> <
        /div> <
        /footer> <
        /div>
    );
};

export default AdminLayout;