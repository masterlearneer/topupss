import React, {
    useEffect,
    useState
} from "react";
import AdminLayout from "./components/AdminLayout";
import axios from "axios";
import ArrowBackIcon from "@mui/icons-material/ArrowBack";
import {
    message,
    Table,
    Pagination,
    Select,
    Input
} from "antd";
import moment from "moment";
import "./AdminQueries.css";

const {
    Option
} = Select;

const AdminQueries = () => {
    const [queries, setQueries] = useState(null);
    const [loading, setLoading] = useState(false);
    const [currentPage, setCurrentPage] = useState(1);
    const [pageSize, setPageSize] = useState(10);
    const [statusFilter, setStatusFilter] = useState(null);
    const [ticketIdFilter, setTicketIdFilter] = useState(null);
    const [typeFilter, setTypeFilter] = useState(null);
    const [singleQuery, setSingleQuery] = useState(null);
    const [view, setView] = useState(0);
    const [msg, setMsg] = useState(null);

    const getAllQueries = async () => {
        try {
            setLoading(true);
            const res = await axios.get("/api/admin/get-all-queries", {
                headers: {
                    Authorization: "Bearer " + localStorage.getItem("token"),
                },
            });
            if (res.data.success) {
                setQueries(res.data.data.reverse());
                setLoading(false);
            } else {
                setLoading(false);
            }
        } catch (error) {
            setLoading(false);
            console.log(error);
        }
    };

    async function handleSubmit(id) {
        try {
            const res = await axios.post("/api/contact/update-query", {
                id: id,
                msg: msg,
                person: "admin",
            }, {
                headers: {
                    Authorization: "Bearer " + localStorage.getItem("token"),
                }
            });
            if (res.data.success) {
                message.success(res.data.message);
                getAllQueries();
                setView(0);
                setMsg("");
            } else {
                message.error(res.data.message);
            }
        } catch (error) {
            console.log(error);
        }
    }

    const handleSeen = async (id, status) => {
        try {
            const res = await axios.post(
                "/api/admin/query-seen", {
                    id: id,
                    value: status
                }, {
                    headers: {
                        Authorization: "Bearer " + localStorage.getItem("token"),
                    },
                }
            );
            if (res.data.success) {
                message.success(res.data.message);
                getAllQueries();
            } else {
                message.error(res.data.message);
            }
        } catch (error) {
            console.log(error);
        }
    };

    useEffect(() => {
        getAllQueries();
        // eslint-disable-next-line
    }, []);

    const handlePageChange = (page, pageSize) => {
        setCurrentPage(page);
    };

    const handlePageSizeChange = (current, size) => {
        setPageSize(size);
    };

    const handleStatusFilterChange = (e) => {
        setStatusFilter(e.target.value);
    };
    const handleTicketIdFilterChange = (e) => {
        setTicketIdFilter(e.target.value);
    };

    const handleTypeFilterChange = (e) => {
        setTypeFilter(e.target.value);
    };

    const filteredQueries =
        queries &&
        queries.filter((item) => {
            if (statusFilter && typeFilter) {
                return item.status === statusFilter && item.type === typeFilter;
            } else if (statusFilter) {
                return item.status === statusFilter;
            } else if (typeFilter) {
                return item.type === typeFilter;
            } else if (ticketIdFilter) {
                return item.ticketId === ticketIdFilter;
            } else {
                return true;
            }
        });

    const columns = [{
            title: "Ticket Id",
            dataIndex: "ticketId",
            key: "ticketId",
        },
        {
            title: "Email",
            dataIndex: "email",
            key: "email",
            render: (text, record) => ( <
                span onClick = {
                    () => {
                        setSingleQuery(record); // If you need to set additional data
                        setView(1);
                    }
                }
                className = "clickable-email"
                style = {
                    {
                        cursor: 'pointer',
                        color: 'black'
                    }
                } // Optional: styles to indicate clickable
                >
                {
                    text
                } <
                /span>
            ),
        },
        {
            title: "Mobile",
            dataIndex: "mobile",
            key: "mobile",
        },
        {
            title: "Type",
            dataIndex: "type",
            key: "type",
        },
        {
            title: "Date",
            dataIndex: "created",
            key: "created",
            render: (text) => moment(text).format("DD MMM YYYY, HH:mm:ss"),
        },
        {
            title: "Registered",
            dataIndex: "login",
            key: "login",
            render: (login) => (login ? "Yes" : "No"),
        },
        {
            title: "Message",
            dataIndex: "message",
            key: "message",
            render: (text, record) => ( <
                button onClick = {
                    () => {
                        setSingleQuery(record);
                        setView(1);
                    }
                }
                className = "add-to-cart-btn w-100 rounded-4" >
                View <
                /button>
            ),
        },
        {
            title: "Action",
            dataIndex: "",
            key: "action",
            render: (text, record) => {
                if (record.status === "seen") {
                    return <button
                    onClick = {
                        () => handleSeen(record._id, 'pending')
                    }
                    className = "add-to-cart-btn bg-danger w-100 rounded-4" >
                        Closed <
                        /button>
                } else {
                    return ( <
                        button onClick = {
                            () => handleSeen(record._id, 'seen')
                        }
                        className = "add-to-cart-btn w-100 rounded-4" >
                        Close <
                        /button>
                    );
                }
            },
        },
    ];

    return ( <
        AdminLayout >
        <
        div className = "page-title" >
        <
        h3 className = "m-0" > Queries < /h3> <
        h6 > Total Queries - {
            queries ? .length
        } < /h6> <
        /div> <
        hr / > {
            view === 0 && ( <
                div className = "table-container" >
                <
                div className = "tools" >
                <
                select className = "mr-2 px-2 text-dark my-2 py-1 rounded-2 border-1"
                style = {
                    {
                        width: 200
                    }
                }
                placeholder = "Filter by Status"
                onChange = {
                    handleStatusFilterChange
                } >
                <
                option value = "" > All Status < /option> <
                option value = "pending" > Pending < /option> <
                option value = "seen" > Seen < /option> <
                /select> <
                select className = "mr-2 px-2 text-dark my-2 py-1 rounded-2 border-1"
                style = {
                    {
                        width: 200
                    }
                }
                placeholder = "Filter by Type"
                onChange = {
                    handleTypeFilterChange
                } >
                <
                option value = "" > All Types < /option> <
                option value = "Payment Related Query" >
                Payment Related Queries <
                /option> <
                option value = "In-Game Recharge Query" >
                In - Game Recharge Query <
                /option> <
                option value = "Wanted to be a Reseller" >
                Wanted to be a Reseller <
                /option> <
                option value = "others" > Other Query < /option> <
                /select> <
                input style = {
                    {
                        width: 200
                    }
                }
                placeholder = "Filter by Ticket Id"
                value = {
                    ticketIdFilter
                } // Ensure this is set if using state
                onChange = {
                    handleTicketIdFilterChange
                }
                className = "px-2 text-dark my-2 py-1 rounded-2 border-1" /
                >
                <
                /div> <
                Table dataSource = {
                    filteredQueries ? .slice(
                        (currentPage - 1) * pageSize,
                        currentPage * pageSize
                    )
                }
                columns = {
                    columns
                }
                pagination = {
                    false
                }
                rowKey = "_id" /
                >
                <
                Pagination className = "my-3"
                current = {
                    currentPage
                }
                pageSize = {
                    pageSize
                }
                total = {
                    queries ? .length
                }
                onChange = {
                    handlePageChange
                }
                showSizeChanger onShowSizeChange = {
                    handlePageSizeChange
                }
                /> <
                /div>
            )
        } {
            view === 1 && ( <
                >
                <
                div className = "back-btnn"
                onClick = {
                    () => setView(0)
                } >
                <
                ArrowBackIcon className = "icon" / >
                Back <
                /div> <
                div className = "admin-query-reply query-reply-container" > {
                    singleQuery ? .msg ? .map((item, index) => {
                        return ( <
                            div className = {
                                `query-msg text-dark ${
                    item?.person === "user" ? "user" : "admin"
                  }`
                            } >
                            {
                                item ? .msg
                            } <
                            /div>
                        );
                    })
                } <
                /div> <
                textarea onChange = {
                    (e) => setMsg(e.target.value)
                }
                className = "my-3 form-control"
                name = "msg"
                rows = "4" >
                < /textarea> <
                button onClick = {
                    () => handleSubmit(singleQuery ? ._id)
                }
                className = "register-btn mt-3" >
                Submit <
                /button> <
                />
            )
        } <
        /AdminLayout>
    );
};

export default AdminQueries;