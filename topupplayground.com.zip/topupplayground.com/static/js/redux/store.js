import {
    configureStore
} from "@reduxjs/toolkit";
import {
    alertSlice
} from "./features/alertSlice";
import {
    updateMobileSlice
} from "./features/updateMobileSlice";
import {
    userSlice
} from "./features/userSlice";
import {
    discountSlice
} from "./features/discountSlice";
import footerMenuReducer from './features/footerMenuSlice';
import dataReducer from './features/dataSlice';

export default configureStore({
    reducer: {
        alerts: alertSlice.reducer,
        updateMobileModal: updateMobileSlice.reducer,
        user: userSlice.reducer,
        discount: discountSlice.reducer,
        footerMenu: footerMenuReducer,
        data: dataReducer,
    },
});