import React, {
    useEffect,
    useState
} from "react";
import {
    Navigate
} from "react-router-dom";
import {
    useDispatch
} from "react-redux";
import axios from "axios";
import {
    setUser
} from "../redux/features/userSlice";
import Loader from "../pages/Loader";

const ProtectedRoute = ({
    children
}) => {
    const dispatch = useDispatch();
    const [isAuthenticated, setIsAuthenticated] = useState(false);
    const [isLoading, setIsLoading] = useState(true);

    // get user
    const getUser = async () => {
        try {
            const res = await axios.post(
                "/api/user/getUserData", {
                    token: localStorage.getItem("token"),
                }, {
                    headers: {
                        Authorization: `Bearer ${localStorage.getItem("token")}`,
                    },
                }
            );
            if (res.data.success) {
                dispatch(setUser(res.data.data.user));
                setIsAuthenticated(true);
            } else {
                setIsAuthenticated(false);
            }
        } catch (error) {
            console.error("Error fetching user data:", error);
            setIsAuthenticated(false);
        } finally {
            setIsLoading(false);
        }
    };

    useEffect(() => {
        if (localStorage.getItem("token")) {
            getUser();
        } else {
            setIsLoading(false);
            setIsAuthenticated(false);
        }
        // eslint-disable-next-line
    }, []);

    if (isLoading) {
        return <Loader / > ;
    }

    if (!isAuthenticated) {
        return <Navigate to = "/login" / > ;
    }

    return children;
};

export default ProtectedRoute;