import React, {
    useEffect,
    useState
} from "react";
import "./Layout.css";
import Header from "../Header/Header";
import Footer from "../Footer/Footer";
import {
    useLocation
} from "react-router-dom";
import HeroSvg from "./HeroSvg";
import FooterMenu from "../Footer/FooterMenu";
import WhyTopUpPlayground from "../WhyTopUpPlayground";
import FeaturedBlog from "../Home/FeaturedBlog";
import ReviewUsTrustPilot from "../ReviewUsTrustPilot";

const Layout = ({
        children
    }) => {
        const {
            pathname
        } = useLocation();
        const ScrollToTop = () => {
            const {
                pathname
            } = useLocation();

            useEffect(() => {
                window.scrollTo(0, 0);
                // eslint-disable-next-line
            }, [pathname]);

            return null;
        };
        ScrollToTop();
        return ( <
            React.Fragment >
            <
            div className = "home-page-background pb-lg-0 pb-md-0" >
            <
            HeroSvg / > {
                /* <div className="py-4 bg-warning">

                        </div> */
            } <
            div className = "d-none d-lg-block d-md-block" >
            <
            Header / >
            <
            /div> <
            div className = "body" > {
                children
            } < /div> <
            div className = "d-block" > {
                pathname !== '/' && < div className = "" >
                <
                WhyTopUpPlayground / >
                <
                /div>} <
                Footer / >

                <
                /div> <
                FooterMenu / >
                <
                /div> <
                /React.Fragment>
            );
        };

        export default Layout;